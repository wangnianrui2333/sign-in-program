export interface Option {
  text: string;
  value: string | number;
  icon: string;
}
