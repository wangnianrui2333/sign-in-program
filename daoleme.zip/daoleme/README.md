# shangke_qiandao
上课签到小程序

详细的上线部署教程
https://mp.weixin.qq.com/s/r-IIctgW-flrHc8cgp6upQ
